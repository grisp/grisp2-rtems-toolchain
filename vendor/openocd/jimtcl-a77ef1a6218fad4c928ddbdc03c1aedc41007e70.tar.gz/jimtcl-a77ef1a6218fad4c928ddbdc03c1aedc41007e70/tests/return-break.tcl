return -code break result
